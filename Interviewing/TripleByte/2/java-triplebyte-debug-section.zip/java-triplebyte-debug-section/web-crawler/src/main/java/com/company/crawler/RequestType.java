package com.company.crawler;

public enum RequestType {
    GET, HEAD
}
